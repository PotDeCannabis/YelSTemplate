fx_version 'adamant'
game 'gta5'

Author 'YelSDev'
Description 'https://discord.gg/YzrwD9qNsS'

client_scripts {
	'NativeUI.lua',
	'Config.lua',
	'Client/*.lua'
}

server_scripts {
	'Config.lua',
	'@mysql-async/lib/MySQL.lua',
	'Server/*.lua'
}
