fx_version 'adamant'
game 'gta5'

Author 'YelSDev'
Description 'https://discord.gg/YzrwD9qNsS'

description 'cron'

version '1.0.0'

server_script 'server/main.lua'
