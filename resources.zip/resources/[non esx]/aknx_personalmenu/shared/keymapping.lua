RegisterKeyMapping('personalmenu', 'Ouvrir le Menu F5', 'keyboard', 'F5')
--                  commands.lua    description         dont touch   control for open menu