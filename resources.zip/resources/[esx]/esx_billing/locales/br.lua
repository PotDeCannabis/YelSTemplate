Locales['br'] = {
  ['invoices'] = 'faturas',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'você ~r~recebeu~s~ uma fatura',
  ['paid_invoice'] = 'você ~g~pagou~s~ uma fatura de ~r~$%s~s~',
  ['received_payment'] = 'você ~g~recebeu~s~ um pagamento de ~r~$%s~s~',
  ['player_not_online'] = 'o jogador não está logado',
  ['no_money'] = 'you do not have enough money to pay this bill',
  ['target_no_money'] = 'the player ~r~does not~s~ have enough money to pay the bill!',
}
