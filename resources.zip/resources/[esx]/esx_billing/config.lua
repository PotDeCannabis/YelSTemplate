Config = {}
Config.Locale = 'fr'
Config.Percent = 0.05