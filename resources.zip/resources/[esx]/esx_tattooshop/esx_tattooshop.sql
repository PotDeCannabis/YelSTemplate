USE `essentialmode`;

ALTER TABLE `users`
	ADD COLUMN `tattoos` LONGTEXT
;