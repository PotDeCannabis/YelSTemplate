Locales['es'] = {
  ['tattoo_shop_prompt'] = 'pulsa ~INPUT_PICKUP~ para ~y~tatuarte~s~.',
  ['money_amount']       = '<span style="color:green;">%s€</span>',
  ['part']               = 'parte %s',
  ['go_back_to_menu']    = '< Volver',
  ['tattoo_item']        = 'tattoo %s - %s',
  ['tattoos']            = 'tattoos',
  ['tattoo_shop']        = 'tienda de tattoo',
  ['bought_tattoo']      = 'te has ~y~tatuado~s~ por ~r~%s€~s~, precio de colega',
  ['not_enough_money']   = 'no tienes dinero suficiente, te faltan ~r~%s€~s~'
}
