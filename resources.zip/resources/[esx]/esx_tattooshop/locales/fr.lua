Locales['fr'] = {
  ['tattoo_shop_prompt'] = 'appuyer sur ~INPUT_PICKUP~ pour accéder au ~y~salon de tatouage~s~.',
  ['money_amount']       = '<span style="color:green;">$%s</span>',
  ['part']               = 'partie %s',
  ['go_back_to_menu']    = '< Retour',
  ['tattoo_item']        = 'tatouage %s - %s',
  ['tattoos']            = 'tatouages',
  ['tattoo_shop']        = 'salon de tatouage',
  ['bought_tattoo']      = 'votre nouveau ~y~tatouage~s~ vous a couté ~r~$%s~s~',
  ['not_enough_money']   = 'vous n\'avez pas ~r~assez d\'argent~s~ pour ce tatouage! Il vous manque ~r~$%s~s~'
}
