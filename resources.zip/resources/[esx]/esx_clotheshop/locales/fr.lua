Locales['fr'] = {

	['valid_this_purchase'] = 'valider cet achat ?',
	['yes'] = 'oui',
	['no'] = 'non',
	['name_outfit'] = 'nom de la tenue ?',
	['not_enough_money'] = 'vous n\'avez pas assez d\'argent',
	['press_menu'] = 'appuyez sur ~INPUT_CONTEXT~ pour accéder au menu',
	['clothes'] = 'Boutique de vêtements',
	['you_paid'] = 'vous avez payé $',
	['save_in_dressing'] = 'voulez-vous donner un nom à votre tenue ?',
	['shop_clothes'] = 'magasin de vêtements',
	['player_clothes'] = 'changer tenue - garde robe',
	['shop_main_menu'] = 'bienvenue ! que souhaitez vous faire ?',
	['saved_outfit'] = 'votre tenue à bien été sauvegardé dans la garde robe. Merci de votre visite !',
	['loaded_outfit'] = 'vous avez bien récupéré la tenue de votre garde robe. Merci de votre visite !',
	['suppr_cloth'] = 'supprimer tenue - garde robe',
	['supprimed_cloth'] = 'cette tenue a bien été supprimé de votre garde robe'

}
