fx_version 'bodacious'
game 'gta5'

client_script "synchro.lua"

server_script "synchroserver.lua"
