Config = {}

Config.Locale = 'en'
Config.EnableESXIdentity = false
Config.MaxSalary = 10000
