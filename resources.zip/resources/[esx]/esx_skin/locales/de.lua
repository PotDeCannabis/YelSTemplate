Locales['de'] = {
  ['skin_menu'] = 'Skin Menü',
  ['use_rotate_view'] = 'benutze ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ und ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ um die Sicht zu drehen.',
  ['skin'] = 'Skin ändern',
  ['saveskin'] = 'Skin speichern',
}
