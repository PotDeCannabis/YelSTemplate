Config = {}

Config.Locale = 'fr'

