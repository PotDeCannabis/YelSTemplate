vehicle_generator "airtug" { -54.26639938354492, -1679.548828125, 28.4414, heading = 228.2736053466797 }

spawnpoint 'a_m_y_hipster_01' { x = -277.827728, y = -308.963684, z = 18.2900 }
spawnpoint 'a_m_y_hipster_02' { x = -277.827728, y = -308.963684, z = 18.2900 }