spawnpoint 'a_m_y_skater_01' { x = -277.827728, y = -308.963684, z = 18.2900 }
spawnpoint 'a_m_y_skater_02' { x = -277.827728, y = -308.963684, z = 18.2900 }