---
id: 25
---
#### Additional Configuration Options

These additional configuration are to be set in the server configuration file, in a similar way to
setting the `mysql_connection_string`.
