---
id: 10
name: 'mysql_log_level'
---
This variable gives control over what goes to the console, and what does not. Add the numbers to get the value to set it to.
1: Info, 2: Success, 4: Warning, 8: Error. For example you wanted only Info's and Error's appearing in the server console, you would set it to 9.
(Default: `15`)