---
id: 11
name: 'stringifyObjects'
---
Stringify objects instead of converting to values. (Default: `false`)