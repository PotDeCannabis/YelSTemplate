---
id: 2
name: 'port'
---
The port number to connect to. (Default: `3306`)