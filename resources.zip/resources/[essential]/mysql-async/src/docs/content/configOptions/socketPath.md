---
id: 4
name: 'socketPath'
---
The path to a unix domain socket to connect to. When used `host` and `port` are ignored.