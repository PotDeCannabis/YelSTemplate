---
id: 15
name: 'debug'
---
Prints protocol details to stdout. Can be `true`/`false` or an array of packet type names that should be
printed. (Default: `false`)