server_script '@mysql-async/lib/MySQL.lua'
server_script 'server.lua'